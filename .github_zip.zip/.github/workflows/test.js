console.log("Running quick test...");
let x = 10;
let y = 10;

if (x === y) {
    console.log("Test Passed!");
    process.exit(0);
} else {
    console.log("Test Failed!");
    process.exit(1);
}
